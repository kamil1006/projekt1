package com.komowo.projekt1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Projekt1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
